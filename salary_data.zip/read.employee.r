
unzip("Employee_Profile.zip", exdir = "Employee Profile")

employee <- read.csv("Employee Profile/employee_profile.csv")
print(employee)
