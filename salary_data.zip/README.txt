
# Instructions on how to run the files

## How to Run

1. Place salary_data.csv in the notebook folder
2. Run the Jupyter Notebook cells in order
3. Use export_employee_profile("NAME", salary_df) to generate ZIP
4. Run read_employee.R to view employee data

## Requirements
Python 3
pandas
R (for step 6)
