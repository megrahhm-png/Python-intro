import os
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file
from pymongo import MongoClient
from models import User

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
application = app  # for AWS Elastic Beanstalk

# Use MONGO_URI from environment (set this later on AWS)
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client.survey_db
collection = db.user_data

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/submit", methods=["POST"])
def submit():
    try:
        total_income = float(request.form.get("total_income", 0))
        user_data = {
            "age": int(request.form["age"]),
            "gender": request.form["gender"],
            "total_income": total_income,
            "expenses": {
                "utilities": float(request.form.get("utilities", 0) or 0),
                "entertainment": float(request.form.get("entertainment", 0) or 0),
                "school_fees": float(request.form.get("school_fees", 0) or 0),
                "shopping": float(request.form.get("shopping", 0) or 0),
                "healthcare": float(request.form.get("healthcare", 0) or 0),
            },
            "timestamp": datetime.utcnow(),
        }
        collection.insert_one(user_data)
        return jsonify({"status": "success", "message": "Survey submitted. Thank you!"})
    except Exception as exc:  # keep simple for beginner
        return (
            jsonify(
                {
                    "status": "error",
                    "message": f"Could not save data: {exc}",
                }
            ),
            500,
        )


@app.route("/export", methods=["GET"])
def export():
    """Export survey data to CSV and download it."""
    user = User()
    filename = user.export_to_csv()
    # File is created in the same folder as app.py
    filepath = os.path.join(BASE_DIR, filename)
    return send_file(filepath, as_attachment=True)


if __name__ == "__main__":
    app.run()
