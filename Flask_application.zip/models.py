from pymongo import MongoClient
import csv
import os
from datetime import datetime


class User:
    def __init__(self, mongo_uri="mongodb://localhost:27017/"):
        self.client = MongoClient(mongo_uri)
        self.db = self.client["survey_db"]
        self.collection = self.db["user_data"]

    def export_to_csv(self, filename="survey_data.csv"):
        """Export all user data to CSV (no pandas, uses built-in csv)."""
        data = list(self.collection.find())

        # Ensure directory exists
        dirname = os.path.dirname(os.path.abspath(filename))
        if dirname and not os.path.exists(dirname):
            os.makedirs(dirname, exist_ok=True)

        # Define CSV column order
        fieldnames = [
            "age",
            "gender",
            "total_income",
            "utilities",
            "entertainment",
            "school_fees",
            "shopping",
            "healthcare",
            "timestamp",
        ]

        with open(filename, mode="w", newline="", encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()

            for record in data:
                expenses = record.get("expenses", {}) or {}
                row = {
                    "age": record.get("age"),
                    "gender": record.get("gender"),
                    "total_income": record.get("total_income"),
                    "utilities": expenses.get("utilities", 0),
                    "entertainment": expenses.get("entertainment", 0),
                    "school_fees": expenses.get("school_fees", 0),
                    "shopping": expenses.get("shopping", 0),
                    "healthcare": expenses.get("healthcare", 0),
                    "timestamp": record.get("timestamp"),
                }
                writer.writerow(row)

        print(f"Exported {len(data)} records to {filename}")
        return filename


if __name__ == "__main__":
    user = User()
    user.export_to_csv()
