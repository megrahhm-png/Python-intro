Income Spending Survey Tool
Project Description

The Income Spending Survey Tool is a web-based data collection and analysis system developed using Flask and MongoDB. The application gathers demographic and financial data from participants to analyze income patterns and spending behavior. The results support strategic decision-making for a healthcare product launch.

This project demonstrates full-stack data workflow:
- Web form data collection
- Database storage
- CSV export
- Data analysis in Jupyter
- Visualization for presentation
- Cloud deployment readiness

## Features
- Web survey form built with Flask
- MongoDB database storage
- Structured data model using Python class
- CSV export for analytics
- Jupyter notebook analysis
- Automated data visualizations
- PowerPoint-ready charts
- Deployment-ready architecture

## Tech Stack
### Backend
- Python
- Flask
- PyMongo

### Database
- MongoDB

### Data Analysis
- Pandas
- Matplotlib
- Jupyter Notebook

### Deployment
- AWS EC2 (ready)

Flask-healthcare-Application/
│
├── app.py                  # Main Flask application
├── requirements.txt        # Dependencies
├── 
├── templates/              # HTML templates
│   └── index.html
│
├── models/                 # Data models
│   └── user.py
│
├── data/                   # Exported CSV files
│   └── users.csv
│
├── notebooks/              # Analysis notebooks
│   └── data_analysis.ipynb
│
└── README.md               # Documentation
│

## Installation & Set up
1. Clone repository
2. Create virtual environment
3. Install Dependencies
4. Start MongoDB
5. Run Flask Application
- Open browser http://127.0.0.1:5000

## Data Collected
### The survey collects:
- Age
- Gender
- Total Income
- Spending categories:
Utilities
Entertainment
School Fees
Shopping
Healthcare

## Data Processing Workflow
- User submits form
- Data stored in MongoDB
- Records exported to CSV
- CSV loaded into Jupyter notebook
- Analysis performed using pandas
- Charts generated using matplotlib
Charts exported for presentation use

## Visualizations Generated
### The notebook produces:
1. Average Income by Age
Identifies age groups with highest earning power

2. Gender Spending Distribution
Compares spending patterns across categories

Charts are saved as PNG files inside:
These are presentation-ready for PowerPoint or reports.

## AWS Deployment Overview
The application can be deployed on an AWS EC2 instance.
### Deployment steps:
Launch EC2 instance
Install Python and dependencies
Upload project files
Run Flask app
Access via public IP
