This project analyzes Netflix Movies and TV Shows data using Python and R to uncover meaningful insights through visual analytics.
The objective is to perform data preparation, cleaning, exploration, statistical analysis, and visualization to support data-driven decision-making, similar to what a Software Developer or Data Analyst at Netflix would do.

The project fulfills the following key tasks:
Data preparation and cleaning
Exploratory data analysis
Statistical summaries
Data visualization in Python
R integration for one visualization

## The dataset provided had the following information:
show_id
type
title
director
cast
country
date_added
release_year
rating
duration
listed_in
description

## Tools
# Python
pandas / Data manipulation
matplotlib / Visualization
seaborn / Statistical plotting

# R
ggplot2_Visualization
readr_Data loading

## Software

Jupyter Notebook
RStudio / R environment

## How to Run: Python
Open Jupyter Notebook and run netflix_analysis.ipynb
This notebook perform the following:
Data exploration
Data cleaning
Statistical analysis
Genre and ratings visualizations

## Data exploration:
In Cell 1 to 3, the dataset was imported and renamed as data/Netflix_shows_movies.csv

## Data Cleaning
In Cell 5, reading the renamed file, checking for missing values, filling and/or dropping missing values

## Statistical analyses
All statistical analyses were perfomed in Cell 6

## Data Visualization (Python)
In Cell 8, Top ten most watched genres on Netflix
In Cell 10, Ratings distribution on Netflix

## How to Run: R
Open Rstudio and run netflix_visuals.R

R Visual

Ratings Distribution (R implementation)