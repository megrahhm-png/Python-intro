library(ggplot2)
library(readr)

df <- read_csv("data/Netflix_shows_movies.csv")

dir.create("outputs", showWarnings = FALSE)

ggplot(df, aes(x = rating)) +
  geom_bar(fill = "steelblue") +
  theme_minimal() +
  labs(title = "Ratings Distribution on Netflix (R)",
       x = "Rating",
       y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave("outputs/ratings_r_plot.png")
