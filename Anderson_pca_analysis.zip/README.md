
# Anderson Cancer Center PCA Project

## Description
This project applies Principal Component Analysis (PCA) on the Breast Cancer dataset from sklearn to identify essential variables and reduce dimensionality to 2 components. 
A Logistic Regression model is optionally implemented for prediction.

## How to Run
1. Install dependencies:
   pip install scikit-learn pandas

2. Run:
   pca_analysis.py

## Outputs
- Explained variance of PCA components
- PCA dataset shape
- Logistic regression accuracy
- Classification report