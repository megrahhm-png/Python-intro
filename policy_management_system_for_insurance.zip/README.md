
# Insurance Policy Management System 

A comprehensive Python-based system for managing insurance policyholders, products and payments.

## Key Features
policyholder.py - For policyholder registration and status
product.py - For managing insurance products
payment.py - For handling payments, reminders and penalties
main.py - Main application to run the system

## How to Run:
1. Ensure you have Python 3 installed on your system.
2. Clone the repository to your local machine.
3. Navigate to the project directory.
4. Run the main application using the command:

## Expected Output:
Dispays details of the two policyholders who have paid for insurance products.
