
class Product:
    def __init__(self, product_id, name, premium):
        self.product_id = product_id
        self.name = name
        self.premium = premium
        self.status = "Active"

    def update_premium(self, new_premium):
        self.premium = new_premium

    def suspend(self):
        self.status = "Suspended"

    def activate(self):
        self.status = "Active"