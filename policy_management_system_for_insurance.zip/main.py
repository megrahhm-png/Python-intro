
from policyholder import Policyholder
from product import Product
from payment import Payment

# Create products
health = Prodcut(1, "Health Insurance", 500)
life = Product(2, "Life Insurance", 300)

# Create policyholder
p1 = Policyholder(101, "Felister Paul")
p2 = Policyholder(102, "David Burton")

# Assign products
p1.add_product(health)
p2.add_product(life)

# Process payments
pay1 = Payment(1, 500)
pay2 = Payment(2,300)

p1.add_payment(pay1)
p2.add_payment(pay2)

# Display details
print(p1.get_details())
print(p2.get_details())