
class Policyholder:
    def __init__(self, policyholder_id, name):
        self.plocyholder_id = policyholder_id
        self.name = name
        self.status = "Active"
        self.products = []
        self.payments = []

    def register(self):
        self.status = "Active"

    def suspend(self):
        self.status = "Suspended"

    def reactivate(self):
        self.status = "Active"

    def add_product(self, product):
        self.products.append(product)

    def add_payment(self, payment):
        self.payments.append(payment)

    def get_details(self):
        return {
            "ID": self.plocyholder_id, 
            "Name": self.name, 
            "Status":self.status, 
            "Products":[p.name for p in self.payments], 
            "Total Payments": sum(p.amount for p in self.payments)
    }    
    

        