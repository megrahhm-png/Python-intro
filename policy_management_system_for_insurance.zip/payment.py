
from datetime import datetime

class Payment:
    def _init_(self, payment_id, amount):
        self.payment_id = payment_id
        self.amount = amount
        self.date = datetime.now()

    def process_payment(self):
        return f"Payment of{self.amount} processed on {self.date}"
    
    def reminder(self):
        return f"Payment reminder sent"
    
    def penalty(self, penalty_amount):
        return f"Penalty of {penalty_amount} applied"