library(keras3)

fashion_mnist <- dataset_fashion_mnist()

train_images <- fashion_mnist$train$x
train_labels <- fashion_mnist$train$y

train_images <- array_reshape(
  train_images / 255,
  dim = c(nrow(train_images), 28, 28, 1)
)

test_images <- fashion_mnist$test$x
test_labels <- fashion_mnist$test$y

test_images <- array_reshape(
  test_images / 255,
  dim = c(nrow(test_images), 28, 28, 1)
)

model <- keras_model_sequential() |>
  layer_conv_2d(
    filters = 32,
    kernel_size = c(3, 3),
    activation = "relu",
    input_shape = c(28, 28, 1)
  ) |>
  layer_max_pooling_2d(pool_size = c(2, 2)) |>
  layer_conv_2d(
    filters = 64,
    kernel_size = c(3, 3),
    activation = "relu"
  ) |>
  layer_max_pooling_2d(pool_size = c(2, 2)) |>
  layer_flatten() |>
  layer_dense(units = 10, activation = "softmax")

model |> compile(
  optimizer = optimizer_adam(),
  loss = loss_sparse_categorical_crossentropy(),
  metrics = c("accuracy")
)

history <- model |> fit(
  x = train_images,
  y = train_labels,
  epochs = 5,
  batch_size = 32,
  validation_split = 0.2
)

model |> evaluate(
  x = test_images,
  y = test_labels
)
