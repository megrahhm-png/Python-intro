
# Fashion MNIST CNN Classification Project

## Description
This project demonstrates image classification using a 6-layer CNN on the Fashion MNIST dataset in both Python (Keras) and R (keras). It serves as preparation for user profile image classification for targeted marketing.

## Files
- python
  fashion_mnist_cnn.py → Python CNN implementation

- R
  fashion_mnist_cnn.R → R CNN implementation

- Requirements
  Required Python packages

## How to Run (Python)
pip install -r requirements.txt  
python fashion_mnist_cnn.py

## How to Run (R)
install.packages("keras")  
library(keras)  
source("fashion_mnist_cnn.R")

## Predictions
The model predicts at least two images from the Fashion MNIST test set.
## Predicted images
Ankel Boot and
Pullover

## Future Work
Adapt CNN to profile image classification using transfer learning.
